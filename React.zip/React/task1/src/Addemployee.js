import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Addemployee() {
    const[name,setName] = useState('')
    const[email,setEmail] = useState('')
    const[phone,setPhone] = useState('')
    const[address,setAddress] = useState('')
    const[city,setCity] = useState('')
    const[zip,setZip] = useState('')
    const[doe,setDoe] = useState('')
    const[dob,setDob] = useState('')
    const navigate = useNavigate('')

    function handleform(e){
        e.preventDefault()
        const formdata = {name,email,phone,address,city,zip,doe,dob}

        fetch('/api/insert',{
            method:'POST',
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(formdata)
        }).then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            if(data._id){
                navigate('/employeedata')
            }
        })
    }

    return (
        <section>
            <div className="container">
                <div className="row" >
                    <div className="col-md-12">
                    <form onSubmit={(e)=>{handleform(e)}}>
                        <label className="form-label">Name</label>
                        <input type='text' className="form-control"
                        value={name} onChange={(e)=>{setName(e.target.value)}}
                        />
                        <label className="form-label">Email</label>
                        <input type='text' className="form-control" 
                        value={email} onChange={(e)=>{setEmail(e.target.value)}}
                        />
                        <label className="form-label">Phone Number</label>
                        <input type='number' className="form-control" 
                        value={phone} onChange={(e)=>{setPhone(e.target.value)}}
                        />
                        <label className="form-label">Address</label>
                        <input type='text'  className="form-control"
                        value={address} onChange={(e)=>{setAddress(e.target.value)}}
                        />
                        <label className="form-label">City</label>
                        <input type='text'  className="form-control"
                        value={city} onChange={(e)=>{setCity(e.target.value)}}
                        />
                        <label className="form-label">Zip Code</label>
                        <input type='number' className="form-control"
                        value={zip} onChange={(e)=>{setZip(e.target.value)}}
                        />
                        <label className="form-label">Date of Employment</label>
                        <input type='date' className="form-control"
                        value={doe} onChange={(e)=>{setDoe(e.target.value)}}
                        />
                        <label className="form-label">Date of Birth</label>
                        <input type='date' className="form-control" 
                        value={dob} onChange={(e)=>{setDob(e.target.value)}}
                        />

                        <button type='submit' className="form-control btn btn-primary m-2" > Add Employee </button>
                    </form>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Addemployee;