import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function EmpUpdate() {
    const { id } = useParams()
    const navigate = useNavigate()
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const [phone, setPhone] = useState('')
    const [address, setAddress] = useState('')
    const [city, setCity] = useState('')
    const [zip, setZip] = useState('')
    const [doe, setDoe] = useState('')
    const [dob, setDob] = useState('')

    useEffect(() => {
        fetch(`/api/singhfetchempployee/${id}`).then((res) => { return res.json() }).then((data) => {
            console.log(data)
            setName(data.name)
            setEmail(data.email)
            setPhone(data.phone)
            setAddress(data.address)
            setCity(data.city)
            setZip(data.zip_code)
            setDoe(data.Date_of_employment)
            setDob(data.date_of_birth)
        })
    }, [id])



    function handleform(e) {
        e.preventDefault()
        const formdata = { name, email, phone, address, city, zip, doe, dob }

        fetch(`/api/singleempupdate/${id}`, {
            method: 'PUT',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(formdata)
        }).then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            if(data.message==="successfully updated"){
                navigate('/employeedata')
            }

        })
    }


    return (
        <section>
            <div className="container">
                <div className="row" >
                    <h2 style={{ textAlign: 'center' }}>Employee Update Here {id}</h2>
                    <div className="col-md-12">
                        <form onSubmit={(e) => { handleform(e) }}>
                            <label className="form-label">Name</label>
                            <input type='text' className="form-control"
                                value={name} onChange={(e) => { setName(e.target.value) }}
                            />
                            <label className="form-label">Email</label>
                            <input type='text' className="form-control"
                                value={email} onChange={(e) => { setEmail(e.target.value) }}
                            />
                            <label className="form-label">Phone Number</label>
                            <input type='number' className="form-control"
                                value={phone} onChange={(e) => { setPhone(e.target.value) }}
                            />
                            <label className="form-label">Address</label>
                            <input type='text' className="form-control"
                                value={address} onChange={(e) => { setAddress(e.target.value) }}
                            />
                            <label className="form-label">City</label>
                            <input type='text' className="form-control"
                                value={city} onChange={(e) => { setCity(e.target.value) }}
                            />
                            <label className="form-label">Zip Code</label>
                            <input type='number' className="form-control"
                                value={zip} onChange={(e) => { setZip(e.target.value) }}
                            />
                            <label className="form-label">Date of Employment</label>
                            <input type='date' className="form-control"
                                value={doe} onChange={(e) => { setDoe(e.target.value) }}
                            />
                            <label className="form-label">Date of Birth</label>
                            <input type='date' className="form-control"
                                value={dob} onChange={(e) => { setDob(e.target.value) }}
                            />

                            <button type='submit' className="form-control btn btn-primary m-2" > Update Here </button>
                        </form>
                    </div>
                </div>
            </div>
        </section>

    );
}


export default EmpUpdate;