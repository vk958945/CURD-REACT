import { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom'
import { LoginContext } from './LoginContext';


function Header() {
  const navigate = useNavigate()
  const { loginname, setLoginname,loginstatus,setLoginStatus } = useContext(LoginContext)

  function handleLogout(e){
    localStorage.setItem('loginname','')
    setLoginname(localStorage.getItem('loginname'))
    localStorage.removeItem('loginstatus')
    setLoginStatus(localStorage.getItem('loginstatus'))
    navigate('/login')
  }

  return (
    <section id='header'>
      <nav className="navbar navbar-expand-lg ">
        <div className="container-fluid">
          <Link className="navbar-brand-0 text-lightx 1 " to="/">Navbar</Link>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              {loginstatus ? 
              <>
              <li className="nav-item">
                <Link className="nav-link active text-light" aria-current="page" to="/">Add Employee</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-light" to="/employeedata">Employee Data</Link>
              </li>
              
              <li className="nav-item">
                <Link className="nav-link text-light" to="#">Welcome {loginname}</Link>
              </li>
              <li className="nav-item">
                <button onClick={(e)=>{handleLogout(e)}} className='form-contol btn btn-danger' >Logout</button>
              </li>   
              </>
              :
              <>
              <li className="nav-item">
                <Link className="nav-link text-light" to="/reg">Register Here</Link>
              </li>

              <li className="nav-item">
                <Link className="nav-link text-light" to="/login">Login Here</Link>
              </li>
              
              </>
}
            </ul>
          </div>
        </div>
      </nav>
    </section>
  );
}

export default Header;