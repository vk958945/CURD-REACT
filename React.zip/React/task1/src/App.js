import Footer from "./Footer";
import Header from "./Header";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import Addemployee from "./Addemployee";
import Employeedata from "./Employeedata";
import EmpUpdate from "./EmpUpdate";
import EmpDelete from "./EmpDelete";
import Login from "./Login";
import Reg from "./Reg";
import { useState } from "react";
import { LoginContext } from "./LoginContext";
import Empmoredetail from "./Empmoredetail";

function App() {
  const[loginname,setLoginname] = useState(localStorage.getItem('loginname'))
  const[loginstatus,setLoginStatus] = useState(localStorage.getItem('loginstatus'))
  return (
    <LoginContext.Provider value={{loginname,setLoginname,loginstatus,setLoginStatus}}>
    <Router>
      <Header />
      <Routes>
        <Route path='/' element={<Addemployee/>}></Route>
        <Route path='/employeedata' element={<Employeedata/>}></Route>
        <Route path='/empupdate/:id' element={<EmpUpdate/>}></Route>
        <Route path='/empdelete/:id' element={<EmpDelete/>}></Route>
        <Route path='/reg' element={<Reg/>}></Route>
        <Route path='/login' element={<Login/>}></Route>
        <Route path='/empmoredetail/:id' element={<Empmoredetail/>}></Route>
      </Routes>
      <Footer />
    </Router>
    </LoginContext.Provider>
  );
}

export default App;