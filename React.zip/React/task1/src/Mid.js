function Mid() {
    return ( 
        <h2>
            Mid
        </h2>
     );
}

export default Mid;