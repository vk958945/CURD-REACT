import { useEffect, useState } from "react";
import { Link } from 'react-router-dom'

function Employeedata() {
    const[emp,setEmp] = useState([])
    const[dataloading,setDataloding] = useState(true)
    useEffect(()=>{
        fetch('/api/showempdata').then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            setDataloding(false)
            setEmp(data)
            
        })
    },[])
    return (
        
        <section>
            <div className="container">
                <div className="row">
                    {dataloading && <h2><img src="loader2.gif" alt="" style={{width:'200px', textAlign:'center'}}/></h2>}
                <Link to="/"><button className="form-control btn btn-success m-2 "> Add Employee </button> </Link>
                    <div className="col-md-12">
                        <table className="table table:hover">
                            <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>City</th>
                                <th>Zip code</th>
                                <th>Date of Employment</th>
                                <th>Date of Birth</th>
                                <th>Action 1</th>
                                <th>Action 2</th>
                                <th>Action 3</th>
                            </tr>
                            </thead>
                            <tbody>
                        {emp.map((result,key)=>(
                            <tr key={result._id}>
                                <td>{key+1}</td>
                                <td>{result.name}</td>
                                <td>{result.email}</td>
                                <td>{result.phone}</td>
                                <td>{result.address}</td>
                                <td>{result.city}</td>
                                <td>{result.zip_code}</td>
                                <td>{result.Date_of_employment}</td>
                                <td>{result.date_of_birth}</td>
                                <td><Link to={`/empmoredetail/${result._id}`}> <button className="form-control btn btn-primary"> More Detail </button> </Link></td>
                                <td><Link to={`/empupdate/${result._id}`}> <button className="form-control btn btn-success"> Update </button> </Link></td>
                                <td><Link to={`/empdelete/${result._id}`}> <button className="form-control btn btn-danger"> Delete </button> </Link></td>
                            </tr>
                        ))}
                            
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Employeedata;