function Footer() {
    return ( 
        
        <section id="footer">
        <h4>@ Task 1 Assignment</h4>
        </section>
     );
}

export default Footer;