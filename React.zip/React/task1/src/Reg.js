import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Reg() {
    const[username,setUsername] = useState('')
    const[password,setPassword] = useState('')
    const[message1,setMessage1] = useState('')
    const navigate =  useNavigate()

    function handleReg(e){
        e.preventDefault()
        const formdata = {username,password}
        fetch('/api/reg',{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(formdata)
        }).then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            if(data._id){
                setMessage1('Registration Succesfully"')
                navigate('/login')
            }else{
                setMessage1('Wrong Credital')
            }
        })
    }

    return ( 
        <section id="middle">
            <div className="container">
                <div className="row" id="mid">               
                   <div className="col-md-4"></div>
                    <div className="col-md-4" id="colmid">
                    <h2>Register Here</h2>
                    {message1}
                        <form onSubmit={(e)=>{handleReg(e)}}>
                            <label>Username</label>
                            <input type='text' className="form-control"
                            value={username} onChange={(e)=>{setUsername(e.target.value)}}
                            ></input>
                            <label>Password</label>
                            <input type='text' className="form-control"
                            value={password} onChange={(e)=>{setPassword(e.target.value)}}
                            ></input>
                            <button  type='submit' className="form-control btn btn-primary mt-2 mb-2">Register</button>
                        </form>
                    </div>
                    <div className="col-md-4"></div>
                </div>
            </div>
        </section>
     );
}

export default Reg;