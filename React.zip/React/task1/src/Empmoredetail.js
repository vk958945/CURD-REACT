import { useEffect, useState } from "react";
import { Link, useParams } from 'react-router-dom'

function Empmoredetail() {
    const{id} = useParams()
    const[emp,setEmp] = useState([])
    const[dataloading,setDataloding] = useState(true)
    useEffect(()=>{
        fetch(`/api/showempdatasingle/${id}`).then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            setDataloding(false)
            setEmp(data)
        })
    },[])
    return (
        <>
        <h2>{id}</h2>

        <section>
            <div className="container">
                <div className="row">
                    {dataloading && <h2><img src="loader2.gif" alt="" style={{width:'200px', textAlign:'center'}}/></h2>}
                    <div className="col-md-12">
                        <table className="table table:hover">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>City</th>
                                <th>Zip code</th>
                                <th>Date of Employment</th>
                                <th>Date of Birth</th>
                                <th>Action 1</th>

                            </tr>
                            </thead>
                            <tbody>
                
                            <tr>
                                <td>{emp.name}</td>
                                <td>{emp.email}</td>
                                <td>{emp.phone}</td>
                                <td>{emp.address}</td>
                                <td>{emp.city}</td>
                                <td>{emp.zip_code}</td>
                                <td>{emp.Date_of_employment}</td>
                                <td>{emp.date_of_birth}</td>
                                <td><Link to={`/empdelete/${emp._id}`}> <button className="form-control btn btn-danger"> Delete </button> </Link></td>
                            </tr>
                       
                            
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
        </>
    );
}

export default Empmoredetail;