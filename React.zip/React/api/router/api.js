const router = require('express').Router()
const Addemp = require('../models/task1db')
const Regdb = require('../models/regdb')
const bcrypt = require('bcrypt')


router.post('/insert', async (req, res) => {
   const { name, email, phone, address, city, zip, doe, dob } = req.body
   const record = new Addemp({ name: name, email: email, phone: phone, address: address, city: city, zip_code: zip, Date_of_employment: doe, date_of_birth: doe })
   await record.save()
   res.json(record)
})

router.get('/showempdata', async (req, res) => {
   const record = await Addemp.find()
   res.json(record)
})


router.get('/singhfetchempployee/:id', async (req, res) => {
   const id = req.params.id
   const record = await Addemp.findById(id)
   res.json(record)
})

router.put('/singleempupdate/:id', async (req, res) => {
   const { name, email, phone, address, city, zip, doe, dob } = req.body
   const id = req.params.id
   await Addemp.findByIdAndUpdate(id, { name: name, email: email, phone: phone, address: address, city: city, zip_code: zip, Date_of_employment: doe, date_of_birth: dob })
   res.json({ message: "successfully updated" })
})

router.delete('/singleempdelete/:id', async (req, res) => {
   const id = req.params.id
   await Addemp.findByIdAndDelete(id)
   res.json({ message: "Successfully Delete" })
})

router.get('/showempdatasingle/:id', async (req, res) => {
   const id = req.params.id
   const record = await Addemp.findById(id)
   res.json(record)
})


router.post('/reg', async (req, res) => {
   const { username, password } = req.body
   const usercheck = await Regdb.findOne({ username: username })
   const pass =  await bcrypt.hash(password,10)
   if (usercheck == null) {
      const record = new Regdb({ username: username, password: pass })
      await record.save()
      res.json(record)
   } else 
   {
      res.json({ message: "Username already taken" })
   }

})

router.post('/login',async(req,res)=>{
   const{username,password} = req.body
   const record = await Regdb.findOne({username:username})
   if(record!=null){
      const passcomapre = await bcrypt.compare(password,record.password)
      if(passcomapre){
         res.json(record)
      }else{
         res.json({message:"Wrong Password"})
      }
   }else{
      res.json({message:"Wrong Username"})
   }
})

module.exports = router